import pandas as pd
import random
from datetime import datetime, timedelta

def load_profiles(file_path):
    try:
        # Use usecols to select only the first 9 fields if there are extra columns
        data = pd.read_csv(
            file_path,
            sep="\t",
            header=None,
            names=[
                "user_id", "public", "completion_percentage", "gender", "region",
                "last_login", "registration", "age", "weight",
            ],
            usecols=range(9),  # Limit to the first 9 columns
            na_values=["null"],  # Handle missing values
            on_bad_lines="warn",  # Warn about problematic rows
        )
        # Convert datetime columns
        data["last_login"] = pd.to_datetime(data["last_login"], errors="coerce")
        data["registration"] = pd.to_datetime(data["registration"], errors="coerce")
        print(f"Loaded {len(data)} profiles successfully.")
        print(data.head())  # Display the first few rows
        return data
    except Exception as e:
        raise ValueError(f"Error loading profiles file: {e}")

def load_relationships(file_path):
    try:
        relationships = pd.read_csv(
            file_path,
            sep="\t",
            header=None,
            names=["user_a", "user_b"],
            on_bad_lines="warn",  # Warn and skip problematic rows
        )
        print("\n[DEBUG] Relationships Data (First Few Rows):")
        print(relationships.head())  # Inspect loaded data
        print(f"Loaded {len(relationships)} relationships successfully.")
        return relationships
    except Exception as e:
        raise ValueError(f"Error loading relationships file: {e}")


#Quantifier 1 

def find_exists_user(data, region, age_threshold, completion_threshold):
    
    
    filtered_users = data[
        (data["region"].str.lower().str.contains(region.lower(), na=False)) &
        (data["age"] > age_threshold) &
        (data["completion_percentage"] > completion_threshold)
    ]
    print(f"[DEBUG] Found {len(filtered_users)} users matching criteria in region '{region}'.")
    return not filtered_users.empty, filtered_users


#Quantifier 2 

# Universal Quantifier Function
def find_all_users_in_region(data):
    
    valid_regions = []

    # Group users by region
    grouped_data = data.groupby("region")
    
    for region, group in grouped_data:
        users_above_18 = group[group["age"] > 18]  # Filter users above 18
        
        # Debugging output: Show users in the current region
        print(f"[DEBUG] Region: {region}, Users above 18:\n{users_above_18[['user_id', 'age', 'completion_percentage']]}")

        # Check if all users above 18 have completion_percentage >= 50
        if not users_above_18.empty and (users_above_18["completion_percentage"] >= 50).all():
            valid_regions.append(region)

    return valid_regions

# Test the function
try:
    profiles_file = "profiles.txt"  # Replace with the actual path
    relationships_file = "relationships.txt"  # Replace with the actual path

    # Load data
    profiles_data = load_profiles(profiles_file)
    relationships_data = load_relationships(relationships_file)
   
# Existential Quantifier Example
    region_name = "zilinsky kraj"
    age_threshold = 15
    completion_threshold = 50
    print("\n--- Existential Quantifier ---")

    exists, users = find_exists_user(profiles_data, region_name, age_threshold, completion_threshold)
    if exists:
        print(f"There exists a user in '{region_name}', above age {age_threshold} with a completion percentage above {completion_threshold}.")
        print(users[["user_id", "region", "age", "completion_percentage"]])
    else:
        print(f"No users found in '{region_name}' above age {age_threshold} with a completion percentage above {completion_threshold}.") 


# Universal Quantifier Example
    print("\n--- Universal Quantifier ---")
    valid_regions = find_all_users_in_region(profiles_data)
    if valid_regions:
        print("Regions where all users above 18 have completed at least 50% of their profile:")
        print(valid_regions)
    else:
        print("No regions found where all users above 18 meet the criteria.")

except Exception as e:
    print(f"Error: {e}")
