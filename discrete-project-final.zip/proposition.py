import pandas as pd
import random
from collections import deque
from datetime import datetime, timedelta
from itertools import permutations, combinations

def load_profiles(file_path):
   
    try:
        data = pd.read_csv(
            file_path,
            sep="\t",
            header=None,
            names=[
                "user_id","public","completion_percentage","gender",
                "region","last_login","registration","age","body",
            ],
            na_values=["null"],  # Replace 'null' with NaN
            on_bad_lines="skip",
        )
        # Convert dates to datetime objects
        data["last_login"] = pd.to_datetime(data["last_login"], errors="coerce")
        data["registration"] = pd.to_datetime(data["registration"], errors="coerce")
        data["age"] = pd.to_numeric(data["age"], errors="coerce")
        print(f"Loaded {len(data)} profiles successfully.")
        return data
    except Exception as e:
        raise ValueError(f"Error loading profiles file: {e}")

def load_relationships(file_path):
    try:
        relationships = pd.read_csv(
            file_path,
            sep="\t",
            header=None,
            names=["user_a", "user_b"],
            on_bad_lines="warn",  # Warn and skip problematic rows
        )
        print("\n[DEBUG] Relationships Data (First Few Rows):")
        print(relationships.head())  # Inspect loaded data
        print(f"Loaded {len(relationships)} relationships successfully.")
        return relationships
    except Exception as e:
        raise ValueError(f"Error loading relationships file: {e}")


# Propositions
def proposition1(user):
    
    if pd.notnull(user["age"]) and user["age"] > 30:
        return user["completion_percentage"] > 50
    return True  

def proposition2(user):
    
    is_public = user["public"] == 1
    last_login = user["last_login"]
    if pd.notnull(last_login):
        one_year_ago = datetime.now() - timedelta(days=365)
        logged_in_last_year = last_login >= one_year_ago
    else:
        logged_in_last_year = False
    return is_public == logged_in_last_year


#main 
try:
    profiles_file = "profiles.txt"  # Replace with the actual path
    relationships_file = "relationships.txt"  # Replace with the actual path

    # Load data
    profiles_data = load_profiles(profiles_file)
    relationships_data = load_relationships(relationships_file)

    # Example: Random User Comparisons
    random_indices = random.sample(range(len(profiles_data)), 2)
    user1 = profiles_data.iloc[random_indices[0]]
    user2 = profiles_data.iloc[random_indices[1]]

    print("\n--- Proposition Results ---")
    print(f"User 1 (ID {user1['user_id']}): Proposition 1 = {proposition1(user1)}, Proposition 2 = {proposition2(user1)}")
    print(f"User 2 (ID {user2['user_id']}): Proposition 1 = {proposition1(user2)}, Proposition 2 = {proposition2(user2)}")


except Exception as e:
    print(f"Error: {e}")
