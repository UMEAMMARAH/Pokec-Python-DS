import pandas as pd

def load_profiles(file_path):
   
   
    try:
        data = pd.read_csv(
            file_path,
            sep="\t",
            header=None,
            names=[
                "user_id", "public", "completion_percentage", "gender", "region",
                "last_login", "registration", "age", "weight",
            ],
            usecols=range(9),  # Limit to the first 9 columns
            na_values=["null"],  # Handle missing values
            on_bad_lines="warn",  # Warn about problematic rows
        )

        # Clean and validate data
        data["completion_percentage"] = pd.to_numeric(data["completion_percentage"], errors="coerce")
        data["region"] = data["region"].str.strip()  # Remove whitespace around region names
        data = data.dropna(subset=["completion_percentage"])  # Drop rows with NaN in completion_percentage
        data = data.drop_duplicates(subset=["user_id"])  # Remove duplicate user entries
        print(f"Loaded {len(data)} profiles successfully.")
        print("\n[DEBUG] Profiles Data (First Few Rows):")
        print(data.head())
        return data
    except Exception as e:
        raise ValueError(f"Error loading profiles file: {e}")

# Strong Induction
def prove_by_strong_induction(data, threshold, X):
   
    print(f"\n--- Prove by Strong Induction ---")
    
    # Step 1: Base case
    base_subset = data.iloc[:1]  # Smallest subset of size 1
    base_count = len(base_subset[base_subset["completion_percentage"] > threshold])
    print(f"Base Case: Subset size = 1, Count = {base_count}")
    if base_count < X:
        print(f"Induction Failed at Base Case!")
        return False

    # Step 2: Strong Induction for subsets of increasing size
    for k in range(2, len(data) + 1):
        subset = data.iloc[:k]  # Subset of size k
        count = len(subset[subset["completion_percentage"] > threshold])
        print(f"Subset size = {k}, Count = {count}")
        if count < X:
            print(f"Induction Failed at Subset Size {k}!")
            return False

    print("Induction Successful: The property holds for all subsets.")
    return True

# Structural Induction
def prove_by_structural_induction(data, threshold, X):
    
    print(f"\n--- Prove by Structural Induction ---")
    
    # Step 1: Group data by region
    grouped_data = data.groupby("region")
    
    for region, group in grouped_data:
        count = len(group[group["completion_percentage"] > threshold])
        print(f"Region: {region}, Count = {count}")
        if count < X:
            print(f"Induction Failed for Region: {region}!")
            return False
    
    print("Induction Successful: The property holds for all regions.")
    return True


# Main Execution
try:
    profiles_file = "profiles.txt"  # Replace with the actual path
    profiles_data = load_profiles(profiles_file)

    # Parameters
    threshold = 20  # Completion percentage threshold
    X = 1           # Minimum number of users expected

    # Strong Induction
    prove_by_strong_induction(profiles_data, threshold, X)

    # Structural Induction
    prove_by_structural_induction(profiles_data, threshold, X)

except Exception as e:
    print(f"Error: {e}")
