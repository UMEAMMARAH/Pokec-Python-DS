import pandas as pd
from datetime import datetime
# Load Profiles Function
def load_profiles(file_path):
   
    try:
        # Load the data and allow warning on bad lines
        data = pd.read_csv(
            file_path,
            sep="\t",  # Assuming tab-separated values
            header=None,
            names=[
                "user_id", "public", "completion_percentage", "gender",
                "region", "last_login", "registration", "age", "body"
            ],
            na_values=["null"],  # Replace 'null' with NaN
            on_bad_lines='warn',  # Warn on bad lines rather than skipping them
        )
        
        # Check how many rows were successfully loaded
        print(f"Loaded {len(data)} rows.")
        
        # Print the first few rows to debug
        print("First few rows of the loaded data:")
        print(data.head())

        # Convert dates to datetime objects
        data["last_login"] = pd.to_datetime(data["last_login"], errors="coerce")
        data["registration"] = pd.to_datetime(data["registration"], errors="coerce")
        
        # Ensure 'age' is numeric and handle errors
        data["age"] = pd.to_numeric(data["age"], errors="coerce")
        
        # Print out any rows that have null or problematic data (e.g., empty columns)
        print("Rows with missing values or problematic data:")
        print(data[data.isnull().any(axis=1)])

        print(f"Successfully loaded {len(data)} profiles.")
        return data

    except Exception as e:
        raise ValueError(f"Error loading profiles file: {e}")

# Load Relationships Function
def load_relationships(file_path):
    try:
        relationships = pd.read_csv(file_path, sep="\t", header=None, names=["user_a", "user_b"])
        print(f"Loaded {len(relationships)} rows from relationships file.")
        return relationships
    except Exception as e:
        raise ValueError(f"Error loading relationships file: {e}")

#RELATI0NS:
# Check Reflexive, Symmetric, Transitive properties of relationships
def check_relationship_properties(relationships):
   
    # Convert relationships to a set of tuples for easy querying
    relationship_set = set(zip(relationships["user_a"], relationships["user_b"]))

    # 1. Reflexive: Check if every user has a relationship with themselves
    users = set(relationships["user_a"]).union(set(relationships["user_b"]))
    reflexive_missing = [user for user in users if (user, user) not in relationship_set]

    # 2. Symmetric: Check if for every (A, B), (B, A) also exists
    symmetric_missing = [(a, b) for a, b in relationship_set if (b, a) not in relationship_set]

    # 3. Transitive: Check if for (A, B) and (B, C), (A, C) exists
    transitive_missing = []
    for a, b in relationship_set:
        for c in users:
            if (b, c) in relationship_set and (a, c) not in relationship_set:
                transitive_missing.append((a, c))

    # Print results
    print("\n--- Relationship Properties ---")
    print(f"Reflexive: {'Yes' if not reflexive_missing else 'No'}")
    if reflexive_missing:
        print(f"Missing reflexive relationships: {reflexive_missing}")

    print(f"Symmetric: {'Yes' if not symmetric_missing else 'No'}")
    if symmetric_missing:
        print(f"Missing symmetric relationships: {symmetric_missing}")

    print(f"Transitive: {'Yes' if not transitive_missing else 'No'}")
    if transitive_missing:
        print(f"Suggested transitive relationships to add: {transitive_missing}")

# Main Execution
try:
    # File paths
    profiles_file = "profiles.txt"  # Replace with the actual path
    relationships_file = "relationships.txt"  # Replace with the actual path

    # Load data
    profiles_data = load_profiles(profiles_file)
    relationships_data = load_relationships(relationships_file)

 # Check relationship properties
    check_relationship_properties(relationships_data)
except Exception as e:
    print(f"Error: {e}")