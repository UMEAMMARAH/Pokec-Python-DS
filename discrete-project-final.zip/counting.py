import pandas as pd

def load_profiles(file_path):
   
    try:
        data = pd.read_csv(
            file_path,
            sep="\t",
            header=None,
            names=[
                "user_id", "public", "completion_percentage", "gender", "region",
                "last_login", "registration", "age", "details", "notes"
            ],
            usecols=range(10),  # Adjust to fit the number of columns in the file
            na_values=["null"],  # Treat "null" as missing values
            on_bad_lines="warn",  # Warn about problematic rows
        )
        
        # Convert columns to appropriate data types
        data["completion_percentage"] = pd.to_numeric(data["completion_percentage"], errors="coerce")
        data["public"] = pd.to_numeric(data["public"], errors="coerce")
        
        # Drop rows with missing user_id
        data = data.dropna(subset=["user_id"])

        print(f"Loaded {len(data)} profiles successfully.")
        return data
    except Exception as e:
        raise ValueError(f"Error loading profiles file: {e}")

def count_high_completion(data, threshold=80):
    
    # Filter data based on completion percentage
    high_completion_users = data[data["completion_percentage"] > threshold]
    count = len(high_completion_users)

    print(f"Total number of users with completion_percentage > {threshold}: {count}")
    return count

def count_users_per_region(data):
   
    # Group by region and count unique user IDs
    region_counts = data.groupby("region")["user_id"].count()

    print("\nNumber of users in each region:")
    print(region_counts)
    return region_counts

def count_public_profiles(data):
    
    # Filter where public == 1
    public_count = len(data[data["public"] == 1])

    print(f"\nTotal number of public profiles: {public_count}")
    return public_count

# Main Execution
try:
    profiles_file = "profiles1.txt"  # Replace with your actual file path

    # Load data
    profiles_data = load_profiles(profiles_file)

    # Perform counting
    count_high_completion(profiles_data, threshold=50)  # Users with >80% completion
    count_users_per_region(profiles_data)  # Users per region
    count_public_profiles(profiles_data)  # Public profiles count

except Exception as e:
    print(f"Error: {e}")
