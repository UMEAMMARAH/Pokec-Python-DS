import pandas as pd
from collections import deque
import networkx as nx
import matplotlib.pyplot as plt

# Load relationships into a DataFrame
def load_relationships(file_path):
    
    try:
        relationships = pd.read_csv(file_path, sep="\t", header=None, names=["user1", "user2"])
        print("Relationships loaded successfully.")
        
        # Drop rows with missing values
        relationships.dropna(subset=["user1", "user2"], inplace=True)
        relationships["user1"] = relationships["user1"].astype(int)
        relationships["user2"] = relationships["user2"].astype(int)
        
        print(f"Relationships after cleaning: {len(relationships)}")
        return relationships
    except Exception as e:
        print(f"Error reading relationships file: {e}")
        return pd.DataFrame()

# Check if a graph is bipartite
def is_bipartite(relationships):
    
    # Build graph as an adjacency list (undirected)
    graph = {}
    for _, row in relationships.iterrows():
        u, v = row["user1"], row["user2"]
        if u not in graph:
            graph[u] = []
        if v not in graph:
            graph[v] = []
        graph[u].append(v)
        graph[v].append(u)  # Undirected edge

    # Initialize color map for bipartite check
    color = {}

    # Traverse each connected component
    for node in graph:
        if node not in color:  # Not yet visited
            queue = deque([node])
            color[node] = 0  # Start with color 0

            while queue:
                current = queue.popleft()
                for neighbor in graph[current]:
                    if neighbor not in color:
                        color[neighbor] = 1 - color[current]  # Alternate color
                        queue.append(neighbor)
                    elif color[neighbor] == color[current]:
                        return False  # Found two adjacent nodes with the same color
    return True

# Calculate Minimum Spanning Tree (MST) using Kruskal's Algorithm
def calculate_mst(relationships):
    
    # Add weights to relationships (assigning arbitrary weights)
    relationships["weight"] = 1  # All edges have weight 1 for simplicity

    # Sort edges by weight
    sorted_edges = relationships.sort_values("weight")

    # Union-Find data structure to manage connected components
    parent = {}
    rank = {}

    # Find function (with path compression)
    def find(node):
        if parent[node] != node:
            parent[node] = find(parent[node])
        return parent[node]

    # Union function (with union by rank)
    def union(node1, node2):
        root1 = find(node1)
        root2 = find(node2)
        if root1 != root2:
            if rank[root1] > rank[root2]:
                parent[root2] = root1
            elif rank[root1] < rank[root2]:
                parent[root1] = root2
            else:
                parent[root2] = root1
                rank[root1] += 1

    # Initialize union-find structure
    nodes = pd.concat([relationships["user1"], relationships["user2"]]).unique()
    for node in nodes:
        parent[node] = node
        rank[node] = 0

    # Build MST
    mst = []
    for _, edge in sorted_edges.iterrows():
        u, v = edge["user1"], edge["user2"]
        if find(u) != find(v):  # If they belong to different sets
            union(u, v)
            mst.append((u, v, edge["weight"]))  # Add edge to MST

    return mst

# Plot the graph using NetworkX
def plot_graph(relationships, mst_edges=None, title="Graph"):
   
    # Create a graph object
    G = nx.Graph()

    # Add edges to the graph
    for _, row in relationships.iterrows():
        G.add_edge(row["user1"], row["user2"])

    # Plot the graph
    pos = nx.spring_layout(G)  # Layout for the graph

    plt.figure(figsize=(10, 8))
    nx.draw(
        G,
        pos,
        with_labels=True,
        node_size=700,
        node_color="lightblue",
        font_size=10,
        edge_color="gray",
    )

    # Highlight MST edges, if provided
    if mst_edges:
        mst_edges_set = set((u, v) for u, v, _ in mst_edges)
        nx.draw_networkx_edges(
            G,
            pos,
            edgelist=mst_edges_set,
            edge_color="red",
            width=2.0,
        )

    plt.title(title)
    plt.show()

if __name__ == "__main__":
    # Path to relationships.txt
    relationships_file = "relationships1.txt"  # Replace with your file path

    # Load relationships
    relationships_df = load_relationships(relationships_file)

    if not relationships_df.empty:
        # Check if the graph is bipartite
        bipartite = is_bipartite(relationships_df)
        print(f"Is the graph bipartite? {'Yes' if bipartite else 'No'}")

        # Calculate Minimum Spanning Tree
        mst = calculate_mst(relationships_df)
        print("Minimum Spanning Tree:")
        for edge in mst:
            print(f"Edge: {edge[0]} - {edge[1]}, Weight: {edge[2]}")

        # Plot the original graph and MST
        plot_graph(relationships_df, mst_edges=mst, title="Graph with MST Highlighted")
    else:
        print("No relationships data to process.")

