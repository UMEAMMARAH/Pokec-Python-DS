import pandas as pd
from collections import deque
import matplotlib.pyplot as plt
import networkx as nx

# Define a TreeNode class to represent each user and their friends
class TreeNode:
    def __init__(self, value):
        self.value = value
        self.children = []

    def add_child(self, child):
        self.children.append(child)

# Iterative function to build the tree from a list of relationships (as a dictionary)
def build_tree(root_id, relationships):
    root = TreeNode(root_id)
    queue = deque([root])

    visited = set([root_id])

    while queue:
        current_node = queue.popleft()
        current_user = current_node.value

        for friend in relationships.get(current_user, []):
            if friend not in visited:
                visited.add(friend)
                friend_node = TreeNode(friend)
                current_node.add_child(friend_node)
                queue.append(friend_node)

    return root

# Preorder Traversal (Root -> Children)
def preorder(node):
    result = []
    result.append(node.value)  # Visit the root first
    for child in node.children:
        result.extend(preorder(child))  # Recursively visit the children
    return result

# Postorder Traversal (Children -> Root)
def postorder(node):
    result = []
    for child in node.children:
        result.extend(postorder(child))  # Recursively visit the children
    result.append(node.value)  # Visit the root after its children
    return result

# Breadth-First Traversal (Level by Level)
def breadth_first(node):
    queue, result = deque([node]), []
    while queue:
        curr = queue.popleft()
        result.append(curr.value)
        queue.extend(curr.children)
    return result

# Inorder-like Traversal (For general trees)
def inorder_like(node):
    result = []
    if node.children:
        # Visit first child, then root, then other children
        result.extend(inorder_like(node.children[0]))  # Leftmost child
        result.append(node.value)  # Root
        for child in node.children[1:]:  # Other children
            result.extend(inorder_like(child))
    else:
        result.append(node.value)  # If no children, just the node itself
    return result

# Function to read relationships from a file and create a dictionary of user relationships
def load_relationships(file_path):
    relationships = {}
    try:
        # Read the file with user relationships
        with open(file_path, 'r') as file:
            for line in file:
                user1, user2 = map(int, line.strip().split())
                if user1 not in relationships:
                    relationships[user1] = []
                if user2 not in relationships:
                    relationships[user2] = []  # If user2 is not in the dictionary, initialize an empty list
                
                relationships[user1].append(user2)  # Add user2 as a friend of user1
                relationships[user2].append(user1)  # Since the relationship is bidirectional
        return relationships
    except Exception as e:
        print(f"Error reading file: {e}")
        return {}

# Function to draw the tree using NetworkX and Matplotlib
def draw_tree(root):
    G = nx.DiGraph()

    def add_edges(node):
        for child in node.children:
            G.add_edge(node.value, child.value)
            add_edges(child)
    
    add_edges(root)
    
    pos = nx.spring_layout(G)
    nx.draw(G, pos, with_labels=True, node_color='skyblue', node_size=3000, font_size=15, font_weight='bold', arrows=True)
    plt.show()

if __name__ == "__main__":
    # Path to your relationships.txt file
    relationships_file = 'relationships1.txt'  # Replace with your file path

    # Load relationships from file
    relationships = load_relationships(relationships_file)

    # We will treat user 1 as the root of the tree (if user 1 exists in the data)
    root_id = 1
    if root_id in relationships:
        root = build_tree(root_id, relationships)

        # Perform tree traversals
        print("Tree Structure with root as user 1:")
        print("Preorder Traversal:", preorder(root))
        print("Postorder Traversal:", postorder(root))
        print("Breadth-First Traversal:", breadth_first(root))
        print("Inorder-like Traversal:", inorder_like(root))

        # Draw the tree
        draw_tree(root)
    else:
        print(f"Error: User {root_id} not found in the relationships data.")
