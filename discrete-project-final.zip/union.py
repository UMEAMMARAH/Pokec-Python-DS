import pandas as pd

def load_profiles(file_path):
  
    try:
        # Load the file, limiting to the first 9 columns
        data = pd.read_csv(
            file_path,
            sep="\t",
            header=None,
            names=[
                "user_id", "public", "completion_percentage", "gender", "region",
                "last_login", "registration", "age", "weight",
            ],
            usecols=range(9),  # Ensure only first 9 columns are read
            na_values=["null"],  # Handle missing values
            on_bad_lines="warn",  # Warn about problematic rows
        )

        # Display a preview of the loaded data
        print(f"Loaded {len(data)} profiles successfully.")
        print(data.head())

        # Ensure numeric conversion where needed
        data["public"] = pd.to_numeric(data["public"], errors="coerce")
        data["age"] = pd.to_numeric(data["age"], errors="coerce")

        # Handle datetime conversions
        data["last_login"] = pd.to_datetime(data["last_login"], errors="coerce")
        data["registration"] = pd.to_datetime(data["registration"], errors="coerce")

        return data

    except Exception as e:
        raise ValueError(f"Error loading profiles file: {e}")


def load_relationships(file_path):
    
    try:
        relationships = pd.read_csv(file_path, sep="\t", header=None, names=["user_a", "user_b"])
        print(f"Loaded {len(relationships)} relationships successfully.")
        return relationships
    except Exception as e:
        raise ValueError(f"Error loading relationships file: {e}")


def set_operations(data):
   
    # Set A: Public users
    set_a = set(data[data["public"] == 1]["user_id"])
    print(f"Set A (Public Users): {len(set_a)} users")

    # Set B: Bratislava users
    set_b = set(data[data["region"].str.contains("bratislava", na=False, case=False)]["user_id"])
    print(f"Set B (Bratislava Users): {len(set_b)} users")

    # Perform set operations
    union = set_a | set_b
    intersection = set_a & set_b
    complement_a = set(data["user_id"]) - set_a

    return union, intersection, complement_a


# Main script
try:
    # File paths
    profiles_file = "profiles.txt"  # Replace with the actual path
    relationships_file = "relationships.txt"  # Replace with the actual path

    # Load data
    profiles_data = load_profiles(profiles_file)
    relationships_data = load_relationships(relationships_file)

    # Set Operations
    print("\n--- Set Operations ---")
    union, intersection, complement_a = set_operations(profiles_data)

    # Display Results
    print(f"Union (A ∪ B): {len(union)} users")
    print(f"Intersection (A ∩ B): {len(intersection)} users")
    print(f"Complement of A (A'): {len(complement_a)} users")

except Exception as e:
    print(f"Error: {e}")
