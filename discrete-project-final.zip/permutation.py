import pandas as pd
from itertools import permutations, combinations

# Load Profiles
def load_profiles(file_path):
    try:
        data = pd.read_csv(
            file_path,
            sep="\t",
            header=None,
            names=[
                "user_id", "public", "completion_percentage", "gender", "region",
                "last_login", "registration", "age", "weight",
            ],
            usecols=range(9),  # Limit to the first 9 columns
            na_values=["null"],  # Handle missing values
            on_bad_lines="warn",  # Warn about problematic rows
        )
        # Convert datetime columns
        data["last_login"] = pd.to_datetime(data["last_login"], errors="coerce")
        data["registration"] = pd.to_datetime(data["registration"], errors="coerce")
        print(f"Loaded {len(data)} profiles successfully.")
        return data
    except Exception as e:
        raise ValueError(f"Error loading profiles file: {e}")

# Load Relationships
def load_relationships(file_path):
    try:
        relationships = pd.read_csv(
            file_path,
            sep="\t",
            header=None,
            names=["user_a", "user_b"],
            on_bad_lines="warn",  # Warn and skip problematic rows
        )
        print(f"Loaded {len(relationships)} relationships successfully.")
        return relationships
    except Exception as e:
        raise ValueError(f"Error loading relationships file: {e}")

# Filter Users by Criteria
def filter_users(data, age_threshold=None, region=None):
    filtered_data = data
    if age_threshold is not None:
        filtered_data = filtered_data[filtered_data["age"] > age_threshold]
    if region is not None:
        filtered_data = filtered_data[filtered_data["region"].str.contains(region, na=False, case=False)]
    return filtered_data    

# Count Combinations
def count_combinations(data, group_size):
    if len(data) < group_size:
        print(f"Not enough users to select a group of {group_size}.")
        return 0
    users = data["user_id"].tolist()
    return len(list(combinations(users, group_size)))

# Calculate Permutations
def calculate_permutations(data, property_name):
    if property_name not in data.columns:
        raise ValueError(f"Property '{property_name}' not found in data.")
    
    if data.empty:
        raise ValueError("The data provided is empty. Cannot calculate permutations.")
    
    # Ensure the property_name column doesn't contain all NaN values
    if data[property_name].isna().all():
        raise ValueError(f"All values in '{property_name}' are NaN. Cannot sort by this property.")
    
    # Drop rows with NaN in the property_name to avoid errors
    sorted_data = data.dropna(subset=[property_name]).sort_values(by=property_name, ascending=False)
    
    # Debug print to check sorted data
    print(f"Sorted Data for {property_name}:\n{sorted_data[['user_id', property_name]]}")
    
    if sorted_data.empty:
        raise ValueError("After removing NaN values, no data remains to calculate permutations.")
    
    users = sorted_data["user_id"].tolist()
    print(f"Users for Permutations: {users}")
    return list(permutations(users))

# Main Execution
def main():
    try:
        profiles_file = "profiles.txt"  # Replace with actual file path
        relationships_file = "relationships.txt"  # Replace with actual file path

        # Load Data
        profiles_data = load_profiles(profiles_file)
        relationships_data = load_relationships(relationships_file)

        # User-defined Criteria
        age_threshold = 25
        region = "bratislava"
        group_size = 3
        property_name = "completion_percentage"

        # Filter Users
        print("\n--- Filter Users ---")
        filtered_users = filter_users(profiles_data, age_threshold=age_threshold, region=region)
        print(f"Filtered Users:\n{filtered_users[['user_id', 'age', 'region']]}")

        # Count Combinations
        print("\n--- Count Combinations ---")
        num_combinations = count_combinations(filtered_users, group_size)
        print(f"Number of ways to select {group_size} users: {num_combinations}")

        # Calculate Permutations
        print("\n--- Calculate Permutations ---")
        filtered_profiles = filter_users(profiles_data, age_threshold=age_threshold)
        if not filtered_profiles.empty:
            try:
                permutations_result = calculate_permutations(filtered_profiles, property_name)
                print(f"Sample permutations (based on {property_name}): {permutations_result[:5]}")
            except ValueError as ve:
                print(f"Error in calculating permutations: {ve}")
        else:
            print("No users available to calculate permutations.")

    except Exception as e:
        print(f"Error: {e}")

# Run the Main Function
if __name__ == "__main__":
    main()