import pandas as pd
from matplotlib_venn import venn3
import matplotlib.pyplot as plt

def load_profiles(file_path):
    
    try:
        data = pd.read_csv(
            file_path,
            sep="\t",
            header=None,
            names=[
                "user_id", "public", "completion_percentage", "gender", "region",
                "last_login", "registration", "age", "weight",
            ],
            usecols=range(9),  # Limit to the first 9 columns
            na_values=["null"],  # Handle missing values
            on_bad_lines="warn",  # Warn about problematic rows
        )
        print(f"Loaded {len(data)} profiles successfully.")
        return data
    except Exception as e:
        raise ValueError(f"Error loading profiles file: {e}")

def create_gender_region_public_venn(data, region_filter):
    
    # Define sets
    public_users = set(data[data["public"] == 1]["user_id"])
    male_users = set(data[data["gender"] == 1]["user_id"])  # Male users (gender == 1)
    female_users = set(data[data["gender"] == 0]["user_id"])  # Female users (gender == 0)
    region_users = set(data[data["region"].str.contains(region_filter, na=False, case=False)]["user_id"])

    # Debugging output
    print(f"Public Users: {len(public_users)}")
    print(f"Male Users: {len(male_users)}")
    print(f"Female Users: {len(female_users)}")
    print(f"Users in Region '{region_filter}': {len(region_users)}")

    # Create Venn diagram
    venn = venn3(
        [male_users, female_users, public_users],
        ("Male Users", "Female Users", "Public Users"),
    )

    plt.title(f"Venn Diagram of Users in {region_filter}")
    plt.show()

# Main Execution
try:
    profiles_file = "profiles1.txt"  # Replace with the actual path

    # Load data
    profiles_data = load_profiles(profiles_file)

    # Create the Venn diagram for users in Zilinsky Kraj
    create_gender_region_public_venn(profiles_data, "zilinsky kraj")

except Exception as e:
    print(f"Error: {e}")
